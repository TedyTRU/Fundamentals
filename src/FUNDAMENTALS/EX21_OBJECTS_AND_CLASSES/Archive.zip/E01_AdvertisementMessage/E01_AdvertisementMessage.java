package FUNDAMENTALS.EX21_OBJECTS_AND_CLASSES.E01_AdvertisementMessage;

public class E01_AdvertisementMessage {
}
